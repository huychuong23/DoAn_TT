import React from 'react'
import ChartDoctorBottom from './ChartDoctorBottom'
import TopChartDoctor from './TopChartDoctor'

export default function ChartDoctor() {
  return (
    <>
       
    <ChartDoctorBottom />
    </>
  )
}
